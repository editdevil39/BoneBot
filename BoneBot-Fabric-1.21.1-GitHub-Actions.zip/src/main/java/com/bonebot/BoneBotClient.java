package com.bonebot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class BoneBotClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static boolean enabled = false;
    private static int ticks = 0;

    // IMPORTANT: These are GUI slot indices, not the numbered shop options.
    // Change these after testing the server's GUI:
    private static final int BONE_SHOP_SLOT = -1;      // set to the Bone icon's slot index
    private static final int QUANTITY_SLOT = -1;       // set to the quantity button's slot index
    private static final int BUY_EVERY_TICKS = 20;     // 20 ticks = about 1 second
    private static final boolean AUTO_DROP = false;    // enable only after setting up/testing safely

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.bonebot.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                ticks = 0;
                if (client.player != null) {
                    client.player.sendMessage(Text.literal(
                            "BoneBot " + (enabled ? "ON" : "OFF") +
                            " — open the shop GUI; configure slot indices in BoneBotClient.java first."
                    ), true);
                }
            }

            if (!enabled || client.player == null || client.interactionManager == null) return;
            if (!(client.currentScreen instanceof HandledScreen<?> screen)) return;

            // Safety: do not click anything until the GUI slot indices have been configured.
            if (BONE_SHOP_SLOT < 0 || QUANTITY_SLOT < 0) return;

            ticks++;
            if (ticks < BUY_EVERY_TICKS) return;
            ticks = 0;

            int syncId = screen.getScreenHandler().syncId;
            int slotCount = screen.getScreenHandler().slots.size();
            if (BONE_SHOP_SLOT >= slotCount || QUANTITY_SLOT >= slotCount) {
                client.player.sendMessage(Text.literal("BoneBot: configured slot index is outside this GUI."), true);
                enabled = false;
                return;
            }

            // One purchase sequence. Server GUIs can differ, so test with a low-cost item first.
            client.interactionManager.clickSlot(syncId, BONE_SHOP_SLOT, 0, SlotActionType.PICKUP, client.player);
            client.interactionManager.clickSlot(syncId, QUANTITY_SLOT, 0, SlotActionType.PICKUP, client.player);

            // Auto-dropping is intentionally not implemented generically: many shops deliver items
            // into inventory and server-specific menus differ. Avoid accidental item loss.
        });
    }
}
