# BoneBot (Fabric 1.21.1)

This is a **source project**, not a compiled/tested `.jar`. It is a client-side Fabric mod skeleton with a K toggle and configurable shop GUI slot clicks.

## Important
- It does **not** work out-of-the-box: the Bone and quantity GUI slot indices are deliberately set to `-1` for safety.
- The numbered choices shown in a shop screenshot are not necessarily Minecraft GUI slot indices.
- Server menus vary. Do not enable it on a live server until you have identified the correct GUI slots and checked the server's rules.
- Automatic dropping is not enabled; a generic implementation could accidentally drop valuable items or click the wrong menu button.
- Use only where the server allows automation.

## Build
Requires Java 21 and Gradle. From this folder run:
```sh
gradle build
```
The jar, if the build succeeds, will be in `build/libs/`.

## Configure
Open `src/main/java/com/bonebot/BoneBotClient.java` and set:
- `BONE_SHOP_SLOT`
- `QUANTITY_SLOT`

These values are zero-based slot indices in the open Minecraft GUI, not the labels 1–9 displayed by the server. Press **K** to toggle the helper.
